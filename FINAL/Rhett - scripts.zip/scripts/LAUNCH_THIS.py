'''
_______________ NOTES ___________________

    - STATISTICS LIBRARY MUST BE IN USE IN ORDER TO RUN CALCULATOR
    - CALCULATOR VALUES WILL PRINT IN SCRIPT HISTORY WINDOW
    - Everything works. I couldn't get textfields to work for Calculator and renamer though. :(

'''

import Toolbox
reload (Toolbox)
TB = Toolbox.RWTools()
TB.create()